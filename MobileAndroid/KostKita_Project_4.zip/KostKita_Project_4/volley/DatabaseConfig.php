<?php

//define your host here
$HostName = "localhost";

//define your database username here
$HostUser = "root";

//define your database password here
$HostPass = "";

//define your database name here
$DatabaseName = "user_details_table"

?>