package com.kos.KostKita;

public class ModalData {

    private String NamaKost, AlamatKost, Jeniskost, Stok;

    public String getNamaKost() {
        return NamaKost;
    }
    public void setNamaKost(String NamaKost) {
        this.NamaKost = NamaKost;
    }

    public String getAlamatKost() { return AlamatKost; }
    public void setAlamatKost(String alamatKost) { AlamatKost = alamatKost; }

    public String getJeniskost() { return Jeniskost; }
    public void setJeniskost(String jeniskost) { Jeniskost = jeniskost; }

    public String getStok() { return Stok; }
    public void setStok(String stok) { Stok = stok; }
}
