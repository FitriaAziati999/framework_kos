package com.kos.KostKita.model;

public class Data {

	private String id_kos, id_pemilik, nama_kos, alamat_kos, khusus_kos, fasilitas_kos, lingkungan_kos, peraturan_kos ;

	public String getId_kos() {
		return id_kos;
	}
	public void setId_kos(String id_kos) {
		this.id_kos = id_kos;
	}

	public String getId_pemilik() {
		return id_pemilik;
	}
	public void setId_pemilik(String id_pemilik) {
		this.id_pemilik = id_pemilik;
	}

	public String getNama_kos() {
		return nama_kos;
	}
	public void setNama_kos(String nama_kos) {
		this.nama_kos = nama_kos;
	}

	public String getAlamat_kos() {
		return alamat_kos;
	}
	public void setAlamat_kos(String alamat_kos) {
		this.alamat_kos = alamat_kos;
	}

	public String getKhusus_kos() {
		return khusus_kos;
	}
	public void setKhusus_kos(String khusus_kos) {
		this.khusus_kos = khusus_kos;
	}

	public String getFasilitas_kos() {
		return fasilitas_kos;
	}
	public void setFasilitas_kos(String fasilitas_kos) {
		this.fasilitas_kos = fasilitas_kos;
	}

	public String getLingkungan_kos() {
		return lingkungan_kos;
	}
	public void setLingkungan_kos(String lingkungan_kos) {
		this.lingkungan_kos = lingkungan_kos;
	}

	public String getPeraturan_kos() {
		return peraturan_kos;
	}
	public void setPeraturan_kos(String peraturan_kos) {
		this.peraturan_kos = peraturan_kos;
	}

}
