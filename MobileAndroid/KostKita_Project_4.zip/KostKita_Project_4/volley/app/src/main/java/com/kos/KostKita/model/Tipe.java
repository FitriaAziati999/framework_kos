package com.kos.KostKita.model;

public class Tipe {
    private String ukuran, stok, harga, kapasitas, fasilitas;

    public String getUkuran() { return ukuran; }
    public void setUkuran(String ukuran) { this.ukuran = ukuran; }

    public String getStok() { return stok; }
    public void setStok(String stok) { this.stok = stok; }

    public String getHarga() { return harga; }
    public void setHarga(String harga) { this.harga = harga; }

    public String getKapasitas() { return kapasitas; }
    public void setKapasitas(String kapasitas) { this.kapasitas = kapasitas; }

    public String getFasilitas() { return fasilitas; }
    public void setFasilitas(String fasilitas) { this.fasilitas = fasilitas; }
}
